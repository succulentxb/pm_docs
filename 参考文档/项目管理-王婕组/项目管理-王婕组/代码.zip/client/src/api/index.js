import wepy from 'wepy';

const baseUrl = 'https://api.syang.xyz/api';

const interfaces = {
  async login(code) {
    try {
      const res = await wepy.request({
        url: `${baseUrl}/user/login/wx`,
        method: 'POST',
        data: {code}
			});
			return res;
    } catch(error) {
      console.error(error);
    }
  },
  async register(data) {
		try {
      const res = await wepy.request({
        url: `${baseUrl}/user`,
        header: {'content-type': 'application/x-www-form-urlencoded'},
        method: 'POST',
        data: data
			});
			return res;
    } catch(error) {
      console.error(error);
    }
  },
  async getUser(data) {
    try {
      const res = await wepy.request({
        url: `${baseUrl}/user`,
        data: data
			});
			return res;
    } catch(error) {
      console.error(error);
    }
	},
	async getUserList() {
		try {
      const res = await wepy.request({
        url: `${baseUrl}/user/list`
			});
			return res;
    } catch(error) {
      console.error(error);
    }
	},
	async putUser(data) {
		try {
      const res = await wepy.request({
        url: `${baseUrl}/user`,
        header: {'content-type': 'application/x-www-form-urlencoded'},
        method: 'PUT',
        data: data
			});
			return res;
    } catch(error) {
      console.error(error);
    }
	},
	async deleteUser(data) {
		try {
      const res = await wepy.request({
        url: `${baseUrl}/user`,
        method: 'DELETE',
        data: data
			});
			return res;
    } catch(error) {
      console.error(error);
    }
	},
	async getProject(data) {
		try {
      const res = await wepy.request({
        url: `${baseUrl}/project`,
        data: data
			});
			return res;
    } catch(error) {
      console.error(error);
    }
	},
	async getProjectList() {
		try {
      const res = await wepy.request({
        url: `${baseUrl}/project/list`
			});
			return res;
    } catch(error) {
      console.error(error);
    }
	},
	async newProject(data) {
		try {
      const res = await wepy.request({
        url: `${baseUrl}/project`,
        method: 'POST',
        data: data
			});
			return res;
    } catch(error) {
      console.error(error);
    }
	},
	async putProject(data) {
		try {
      const res = await wepy.request({
        url: `${baseUrl}/project`,
        method: 'PUT',
        data: data
			});
			return res;
    } catch(error) {
      console.error(error);
    }
	},
	async deleteProject(data) {
		try {
      const res = await wepy.request({
        url: `${baseUrl}/project`,
        method: 'DELETE',
        data: data
			});
			return res;
    } catch(error) {
      console.error(error);
    }
	},
	async getMemberList(data) {
		try {
      const res = await wepy.request({
        url: `${baseUrl}/member/list`,
        data: data
			});
			return res;
    } catch(error) {
      console.error(error);
    }
	},
	async newMember(data) {
		try {
      const res = await wepy.request({
        url: `${baseUrl}/member`,
        method: 'POST',
        data: data
			});
			return res;
    } catch(error) {
      console.error(error);
    }
	},
	async putMember(data) {
		try {
      const res = await wepy.request({
        url: `${baseUrl}/member`,
        method: 'PUT',
        data: data
			});
			return res;
    } catch(error) {
      console.error(error);
    }
	},
	async deleteMember(data) {
		try {
      const res = await wepy.request({
        url: `${baseUrl}/project`,
        method: 'DELETE',
        data: data
			});
			return res;
    } catch(error) {
      console.error(error);
    }
	},
	async getScheduleList(data) {
		try {
      const res = await wepy.request({
        url: `${baseUrl}/schedule/list`,
        data: data
			});
			return res;
    } catch(error) {
      console.error(error);
    }
	},
	async newSchedule(data) {
		try {
      const res = await wepy.request({
        url: `${baseUrl}/schedule`,
        method: 'POST',
        data: data
			});
			return res;
    } catch(error) {
      console.error(error);
    }
	},
	async putSchedule(data) {
		try {
      const res = await wepy.request({
        url: `${baseUrl}/schedule`,
        method: 'PUT',
        data: data
			});
			return res;
    } catch(error) {
      console.error(error);
    }
	},
	async deleteSchedule(data) {
		try {
      const res = await wepy.request({
        url: `${baseUrl}/schedule`,
        method: 'DELETE',
        data: data
			});
			return res;
    } catch(error) {
      console.error(error);
    }
	},
	async getAttendancesList(data) {
		try {
      const res = await wepy.request({
        url: `${baseUrl}/attendances/list`,
        data: data
			});
			return res;
    } catch(error) {
      console.error(error);
    }
	},
	async putAttendances(data) {
		try {
      const res = await wepy.request({
				url: `${baseUrl}/attendances`,
        method: 'PUT',				
        data: data
			});
			return res;
    } catch(error) {
      console.error(error);
    }
	},
	async getFileList(data) {
		try {
      const res = await wepy.request({
        url: `${baseUrl}/file/list`,
        data: data
			});
			return res;
    } catch(error) {
      console.error(error);
    }
	},
	async putFile(data) {
		try {
      const res = await wepy.request({
				url: `${baseUrl}/file`,
        method: 'PUT',				
        data: data
			});
			return res;
    } catch(error) {
      console.error(error);
    }
	},
	async deleteFile(data) {
		try {
      const res = await wepy.request({
				url: `${baseUrl}/file`,
        method: 'DELETE',				
        data: data
			});
			return res;
    } catch(error) {
      console.error(error);
    }
	},
	async getAssignmentList(data) {
		try {
      const res = await wepy.request({
        url: `${baseUrl}/assignment/list`,
        data: data
			});
			return res;
    } catch(error) {
      console.error(error);
    }
	},
	async newAssignment(data) {
		try {
      const res = await wepy.request({
        url: `${baseUrl}/assignment`,
        method: 'POST',
        data: data
			});
			return res;
    } catch(error) {
      console.error(error);
    }
	},
	async putAssignment(data) {
		try {
      const res = await wepy.request({
        url: `${baseUrl}/assignment`,
        method: 'PUT',
        data: data
			});
			return res;
    } catch(error) {
      console.error(error);
    }
	},
	async deleteAssignment(data) {
		try {
      const res = await wepy.request({
        url: `${baseUrl}/assignment`,
        method: 'DELETE',
        data: data
			});
			return res;
    } catch(error) {
      console.error(error);
    }
	},
	async newExample(data) {
		try {
      const res = await wepy.request({
        url: `${baseUrl}/example`,
        method: 'POST',
        data: data
			});
			return res;
    } catch(error) {
      console.error(error);
    }
	},
	async putExample(data) {
		try {
      const res = await wepy.request({
        url: `${baseUrl}/example`,
        method: 'PUT',
        data: data
			});
			return res;
    } catch(error) {
      console.error(error);
    }
	},
	async deleteExample(data) {
		try {
      const res = await wepy.request({
        url: `${baseUrl}/example`,
        method: 'DELETE',
        data: data
			});
			return res;
    } catch(error) {
      console.error(error);
    }
	},
	async getWorkList(data) {
		try {
      const res = await wepy.request({
        url: `${baseUrl}/work/list`,
        data: data
			});
			return res;
    } catch(error) {
      console.error(error);
    }
	},
	async newWork(data) {
		try {
      const res = await wepy.request({
        url: `${baseUrl}/work`,
        method: 'POST',
        data: data
			});
			return res;
    } catch(error) {
      console.error(error);
    }
	},
	async putWork(data) {
		try {
      const res = await wepy.request({
        url: `${baseUrl}/work`,
        method: 'PUT',
        data: data
			});
			return res;
    } catch(error) {
      console.error(error);
    }
	},
	async deleteWork(data) {
		try {
			const res = await wepy.request({
				url: `${baseUrl}/work`,
				method: 'DELETE',
				data: data
			});
			return res;
		} catch(error) {
			console.error(error);
		}
	},
	async getEvaluationList(data) {
		try {
      const res = await wepy.request({
        url: `${baseUrl}/evaluation/list`,
        data: data
			});
			return res;
    } catch(error) {
      console.error(error);
    }
	},
	async newEvaluation(data) {
		try {
      const res = await wepy.request({
        url: `${baseUrl}/evaluation`,
        method: 'POST',
        data: data
			});
			return res;
    } catch(error) {
      console.error(error);
    }
	},
	async putEvaluation(data) {
		try {
      const res = await wepy.request({
        url: `${baseUrl}/evaluation`,
        method: 'PUT',
        data: data
			});
			return res;
    } catch(error) {
      console.error(error);
    }
	},
	async deleteEvaluation(data) {
		try {
      const res = await wepy.request({
        url: `${baseUrl}/evaluation`,
        method: 'DELETE',
        data: data
			});
			return res;
    } catch(error) {
      console.error(error);
    }
	},
}

export default interfaces;