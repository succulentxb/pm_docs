const utils = {
  sleep (s) {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        resolve('promise resolved')
      }, s * 1000)
    })
  },
  formatDate (timestamp) {
    const obj = new Date(timestamp);
    const date = [obj.getMonth()+1, obj.getDate()].map((v)=>{
      return v < 10 ? `0${v}` : v;
    });
    date.unshift(obj.getFullYear());
    return date.join('-');
  },
  formatTime (timestamp) {
    const obj = new Date(timestamp);
    const time = [obj.getHours(), obj.getMinutes(), obj.getSeconds()].map((v)=>{
      return v < 10 ? `0${v}` : v;
    });
    return time.join(':');
  },
  formatDateTime(timestamp) {
    return `${this.formatDate(timestamp)} ${this.formatTime(timestamp)}`; 
  },
  computeDateDiff(t1, t2) {
    if(t1 > t2) {
      const tmp = t2;
      t2 = t1;
      t1 = tmp;
    }
    const date1 = new Date(t1);
    const date2 = new Date(t2);
    let years = date2.getFullYear() - date1.getFullYear();
    let months = date2.getMonth() - date1.getMonth();
    let days = date2.getDate() - date1.getDate();
    const fields = ['年', '月']
    const diff = [0, 0]
    if(days < 0) {
      months -= 1;
    }
    if(months < 0) {
      years -= 1;
      months += 12;
    }
    if(years === 0 && months === 0) {
      diff[1] = '<1';
    } else {
      diff[0] = years;
      diff[1] = months;
    }
    return diff.map((v, i)=>{return v ? `${v} ${fields[i]}` : ''}).join('');
  }
}

export default utils;