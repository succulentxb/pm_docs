# Echo-Admin

合唱团管理系统

## 文件结构

* `api` 请求封装
    * `index.js`
* `components` 组件
    * `vant` vant UI 组件
* `mixins`
* `pages`
    * `filesystem.wpy` 文件系统
    * `manage.wpy` 管理
    * `pending.wpy` 待审核
    * `person.wpy` 个人信息
    * `project.wpy` 项目信息
    * `register.wpy` 注册
    * `schedule.wpy` 项目安排
    * `splash.wpy` 预加载
* `resources` 资源文件夹
    * `icons` 图标资源
* `utils` 工具类封装
    * `index.js`
* `app.wpy` 程序入口，基础配置，路由注册……

## 构建命令

```shell
# install node_modules
npm install
# install wepy-cli
npm install wepy-cli -g
# compile
wepy build # wepy build --watch 实时编译
```

## 开发说明

相应的页面文件已经定义，请根据自身需要进行增删，增删相应页面后请及时在 `app.wpy` 页面修改路由

`filesystem` => 文件系统
`manage` => 管理界面
`person` => 个人信息
`project` => 项目信息
`schedule` => 项目进度日程

`index.wpy` 文件作为官方范例提供参考

第一阶段的开发目标为完成每一页面的基本功能，页面跳转 / 样式跳转 / …… 为下一阶段工作

`components` 文件夹下为组件文件夹，目前暂定的组件有 vant ui 组件，参考链接： https://github.com/youzan/vant-weapp

`counter.wpy` / `group.wpy` 等作为官方范例作为参考

`api/index.js` 封装了所有请求，具体封装规则如下

`GET /project` => `async getProject(data)`
`GET /member/list` => `async getMemberList()`
`POST /member` => `async newMember(data)`
`PUT /member` => `async putMember(data)`
`DELETE /member` => `async deleteMember(data)`

除 post 方法按实际意义命名外，命名方式为 `method` + `path`，如 `GET /project`，`method`: `GET`, `path`: `/project`，所以对应接口为 `getProject`, 所需参数通过 json 对象传入，如 `{id: 114514}`，实际调用如下：

```javascript
import interfaces from '../api';
const params = {id: 114514};
const response = await interfaces.getProject(params);
console.log(response)
```

`app.wpy` 封装了两个基本函数 `getUserInfo` => 返回 API 文档中定义的用户基本数据，`getWXUserInfo` => 返回微信用户数据

```javascript
async getWXUserInfo() {
  if (this.globalData.wxUserInfo) {
    return this.globalData.wxUserInfo;
  } else {
    try {
    const {userInfo} = await wepy.getUserInfo();
    this.globalData.uxUserInfo = userInfo;
    return userInfo;
    } catch(err) {
    console.log(err);
    }
  }
}

async getUserInfo() {
  if (this.globalData.userInfo) {
    return this.globalData.userInfo;
  } else {
    const {code}= await wepy.login();
    const response = await interfaces.login(code);
    const userInfo = response.data;
    this.globalData.userInfo = userInfo;
    return userInfo;
  }
}

```

## 开发参考

### wepy 框架

- https://tencent.github.io/wepy/
- https://github.com/Tencent/wepy

### 官方文档

https://developers.weixin.qq.com/miniprogram/dev/

### 微信开发者工具下载地址

https://developers.weixin.qq.com/miniprogram/dev/devtools/download.html