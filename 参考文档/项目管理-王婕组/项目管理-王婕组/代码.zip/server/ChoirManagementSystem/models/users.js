const db = require('../db');

module.exports = db.defineModel('users', {
    openId: {
        type: db.STRING,
        unique: true,
    },
    role: db.INTEGER,
    name: db.STRING,
    gender: db.INTEGER,
    state: db.INTEGER,
    admissionTime: db.BIGINT,
});
