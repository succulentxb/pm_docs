const db = require('../db');

module.exports = db.defineModel('evaluations', {
    readingScore: db.INTEGER,
    accuracyScore: db.INTEGER,
    qualityScore: db.INTEGER,
    plasticityScore: db.INTEGER,
    comment: db.TEXT,
    updatedAt: db.BIGINT,
});
