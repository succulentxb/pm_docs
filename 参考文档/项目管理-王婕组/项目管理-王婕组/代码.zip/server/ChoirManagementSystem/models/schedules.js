const db = require('../db');

module.exports = db.defineModel('schedules', {
    name: db.STRING,
    startTime: db.BIGINT,
    endTime: db.BIGINT,
    detail: db.STRING,
});
