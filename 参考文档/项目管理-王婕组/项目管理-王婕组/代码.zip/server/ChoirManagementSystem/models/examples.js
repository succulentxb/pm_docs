const db = require('../db');

module.exports = db.defineModel('examples', {
    name: db.STRING,
    uuid: db.STRING,
    updatedAt: db.BIGINT,
});
