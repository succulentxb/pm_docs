const db = require('../db');

module.exports = db.defineModel('projects', {
    name: db.STRING,
    startTime: db.BIGINT,
    endTime: db.BIGINT,
    detail: db.TEXT,
    imageUuid: {
        type: db.STRING,
        allowNull: true,
    },
});
