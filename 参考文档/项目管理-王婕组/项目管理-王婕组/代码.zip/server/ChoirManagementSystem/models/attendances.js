const db = require('../db');

module.exports = db.defineModel('attendances', {
    state: {
        type: db.INTEGER,
        defaultValue: 0,
    },
});
