const db = require('../db');

module.exports = db.defineModel('files', {
    name: db.STRING,
    uuid: db.STRING,
    updatedAt: db.BIGINT,
});
