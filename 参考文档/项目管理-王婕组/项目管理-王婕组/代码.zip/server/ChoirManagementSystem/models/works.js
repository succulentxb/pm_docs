const db = require('../db');

module.exports = db.defineModel('works', {
    subpart: db.INTEGER,
    uuid: db.STRING,
    updatedAt: db.BIGINT,
});
