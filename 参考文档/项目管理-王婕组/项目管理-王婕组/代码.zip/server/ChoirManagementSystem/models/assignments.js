const db = require('../db');

module.exports = db.defineModel('assignments', {
    part: db.INTEGER,
    name: db.STRING,
    detail: db.STRING,
    updatedAt: db.BIGINT,
});
