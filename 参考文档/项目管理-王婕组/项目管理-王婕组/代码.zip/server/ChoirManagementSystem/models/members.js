const db = require('../db');

module.exports = db.defineModel('members', {
    part: db.INTEGER,
    role: db.INTEGER,
    score: db.INTEGER,
});
