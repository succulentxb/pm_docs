const Koa = require('koa');
const cors = require('kcors');
const session = require('koa-session');
const body = require('koa-better-body');

const appConfig = require('./configs/app');
const model = require('./model');
const rest = require('./rest');
const controller = require('./controller');

// init db
model.members.belongsTo(model.users, { foreignKey: { name: 'userId', allowNull: false }, onDelete: 'CASCADE' });
model.members.belongsTo(model.projects, { foreignKey: { name: 'projectId', allowNull: false }, onDelete: 'CASCADE' });
model.schedules.belongsTo(model.projects, { foreignKey: { name: 'projectId', allowNull: false }, onDelete: 'CASCADE' });
model.attendances.belongsTo(model.schedules, { foreignKey: { name: 'scheduleId', allowNull: false }, onDelete: 'CASCADE' });
model.attendances.belongsTo(model.members, { foreignKey: { name: 'memberId', allowNull: false }, onDelete: 'CASCADE' });
model.files.belongsTo(model.projects, { foreignKey: { name: 'projectId', allowNull: false }, onDelete: 'CASCADE' });
model.files.belongsTo(model.users, { foreignKey: { name: 'uploaderId', allowNull: false }, onDelete: 'CASCADE', as: 'uploader' });
model.assignments.belongsTo(model.projects, { foreignKey: { name: 'projectId', allowNull: false }, onDelete: 'CASCADE' });
model.assignments.belongsTo(model.users, { foreignKey: { name: 'assignerId', allowNull: false }, onDelete: 'CASCADE', as: 'assigner' });
model.assignments.hasMany(model.examples, { foreignKey: { name: 'assignmentId', allowNull: false }, onDelete: 'CASCADE' });
model.works.belongsTo(model.assignments, { foreignKey: { name: 'assignmentId', allowNull: false }, onDelete: 'CASCADE' });
model.works.belongsTo(model.members, { foreignKey: { name: 'memberId', allowNull: false }, onDelete: 'CASCADE' });
model.evaluations.belongsTo(model.works, { foreignKey: { name: 'workId', allowNull: false }, onDelete: 'CASCADE' });
model.evaluations.belongsTo(model.users, { foreignKey: { name: 'evaluatorId', allowNull: false }, onDelete: 'CASCADE', as: 'evaluator' });
model.sync();

// init app
const app = new Koa();

// enable CORS
app.use(cors({ credentials: true }));

// init session
app.use(session({ signed: false }, app));

// parse request body
app.use(body());

// prepare restful service
app.use(rest.restify());

// add controller
app.use(controller());

// run app
app.listen(appConfig.port);

console.log(`app started at port ${appConfig.port}...`);
