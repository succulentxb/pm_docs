const config = {
    appId: "wx7475001116eabd77",
    appSecret: "26e1f15add3321095826c56b48f8e8a8",

    imageBasePath: '/home/syang/choirmanagement/images',
    imageBaseUrl: 'https://static.syang.xyz/choirmanagement/images',

    fileBasePath: '/home/syang/choirmanagement/files',
    fileBaseUrl: 'https://static.syang.xyz/choirmanagement/files',

    exampleBasePath: '/home/syang/choirmanagement/examples',
    exampleBaseUrl: 'https://static.syang.xyz/choirmanagement/examples',

    workBasePath: '/home/syang/choirmanagement/works',
    workBaseUrl: 'https://static.syang.xyz/choirmanagement/works',
};

module.exports = config;
