const axios = require('axios');

const apiConfig = require('../configs/api');
const APIError = require('../rest').APIError;
const dbUtil = require('../utils/db');
const fileUtil = require('../utils/file');

module.exports = {
    'POST /api/user/login/wx': async (ctx, next) => {
        const { code } = ctx.request.fields;
        if (!code) throw new APIError('request_invalid');

        const response = await axios.get(`https://api.weixin.qq.com/sns/jscode2session?appid=${apiConfig.appId}&secret=${apiConfig.appSecret}&js_code=${code}&grant_type=authorization_code`);
        const { errcode, errmsg } = response.data;
        if (errcode !== 0) throw new APIError('wx_auth_error', errmsg);

        const openId = response.data.openid;
        const user = await dbUtil.getUserByOpenId(openId);
        if (user) {
            ctx.session.userId = user.id;
            ctx.rest({
                exist: true,
                ...user.dataValues,
            });
        } else {
            ctx.rest({
                exist: false,
                openId,
            });
        }

        await next();
    },
    /* for test only */
    'POST /api/user/login/system': async (ctx, next) => {
        const { openId } = ctx.request.fields;
        if (!openId) throw new APIError('request_invalid');

        const user = await dbUtil.getUserByOpenId(openId);
        if (user) {
            ctx.session.userId = user.id;
            ctx.rest({
                exist: true,
                ...user.dataValues,
            });
        } else {
            ctx.rest({
                exist: false,
                openId,
            });
        }

        await next();
    },
    'POST /api/user': async (ctx, next) => {
        const { openId, name, gender, state, admissionTime } = ctx.request.fields;
        if (!(openId && name && gender && state && admissionTime)) throw new APIError('request_invalid');

        let user = await dbUtil.getUserByOpenId(openId);
        if (user) throw new APIError('user_existed');

        user = await dbUtil.createUser({
            openId,
            role: 0,
            name,
            gender: Number(gender),
            state: Number(state),
            admissionTime: Number(admissionTime),
        });

        ctx.session.userId = user.id;
        ctx.rest(user);

        await next();
    },
    'GET /api/user': async (ctx, next) => {
        const { id } = ctx.request.query;
        if (!id) throw new APIError('request_invalid');

        const user = await dbUtil.getUserById(id);
        if (!user) throw new APIError('user_not_exist');

        const members = await dbUtil.getMembersWithProjectByUserId(id);
        members.forEach(member => prepareProject(member.project));
        user.dataValues.members = members;

        ctx.rest(user);

        await next();
    },
    'GET /api/user/list': async (ctx, next) => {
        const users = await dbUtil.getUsers();

        ctx.rest(users);

        await next();
    },
    'PUT /api/user': async (ctx, next) => {
        const { id, role, name, gender, state, admissionTime } = ctx.request.fields;
        if (!id) throw new APIError('request_invalid');

        const { userId } = ctx.session;
        if (!userId) throw new APIError('session_invalid');

        const user = await dbUtil.getUserById(userId);
        if (user.role !== 3) {
            const members = await dbUtil.getMembersByUserId(userId);
            const targetMembers = await dbUtil.getMembersByUserId(id);
            if (!isPartChiefOfUser(members, targetMembers)) throw new APIError('permission_denied');
        }

        const targetUser = await dbUtil.getUserById(id);
        if (!targetUser) throw new APIError('user_not_exist');

        if (role) {
            if (user.role < Number(role)) throw new APIError('permission_denied');
            targetUser.role = Number(role);
        }
        if (name) targetUser.name = name;
        if (gender) targetUser.gender = Number(gender);
        if (state) targetUser.state = Number(state);
        if (admissionTime) targetUser.admissionTime = Number(admissionTime);
        await targetUser.save();

        ctx.rest(targetUser);

        await next();
    },
    'DELETE /api/user': async (ctx, next) => {
        const { id } = ctx.request.query;
        if (!id) throw new APIError('request_invalid');

        const { userId } = ctx.session;
        if (!userId) throw new APIError('session_invalid');

        const user = await dbUtil.getUserById(userId);
        if (user.role !== 3) throw new APIError('permission_denied');

        const targetUser = await dbUtil.getUserById(id);
        if (!targetUser) throw new APIError('user_not_exist');

        await prepareToDeleteUser(targetUser);
        await targetUser.destroy();

        ctx.rest({});

        await next();
    },

    'GET /api/project': async (ctx, next) => {
        const { id } = ctx.request.query;
        if (!id) throw new APIError('request_invalid');

        const project = await dbUtil.getProjectById(id);
        if (!project) throw new APIError('project_not_exist');
        prepareProject(project);

        ctx.rest(project);

        await next();
    },
    'GET /api/project/list': async (ctx, next) => {
        const projects = await dbUtil.getProjects();
        projects.forEach(prepareProject);

        ctx.rest(projects);

        await next();
    },
    'POST /api/project': async (ctx, next) => {
        const { name, startTime, endTime, detail, image } = ctx.request.fields;
        if (!(name && startTime && endTime && detail)) throw new APIError('request_invalid');

        const { userId } = ctx.session;
        if (!userId) throw new APIError('session_invalid');

        const user = await dbUtil.getUserById(userId);
        if (user.role !== 3) throw new APIError('permission_denied');

        let project = {
            name,
            startTime: Number(startTime),
            endTime: Number(endTime),
            detail,
            imageUuid: image ? await fileUtil.saveFile(image[0], apiConfig.imageBasePath) : null,
        };
        project = await dbUtil.createProject(project);
        prepareProject(project);

        ctx.rest(project);

        await next();
    },
    'PUT /api/project': async (ctx, next) => {
        const { id, name, startTime, endTime, detail, image } = ctx.request.fields;
        if (!id) throw new APIError('request_invalid');

        const { userId } = ctx.session;
        if (!userId) throw new APIError('session_invalid');

        const user = await dbUtil.getUserById(userId);
        if (user.role !== 3) throw new APIError('permission_denied');

        const project = await dbUtil.getProjectById(id);
        if (!project) throw new APIError('project_not_exist');

        if (name) project.name = name;
        if (startTime) project.startTime = Number(startTime);
        if (endTime) project.endTime = Number(endTime);
        if (detail) project.detail = detail;
        if (image) {
            if (project.imageUuid) await fileUtil.deleteFile(project.imageUuid, apiConfig.imageBasePath);
            project.imageUuid = await fileUtil.saveFile(image[0], apiConfig.imageBasePath);
        }
        await project.save();
        prepareProject(project);

        ctx.rest(project);

        await next();
    },
    'DELETE /api/project': async (ctx, next) => {
        const { id } = ctx.request.query;
        if (!id) throw new APIError('request_invalid');

        const { userId } = ctx.session;
        if (!userId) throw new APIError('session_invalid');

        const user = await dbUtil.getUserById(userId);
        if (user.role !== 3) throw new APIError('permission_denied');

        const project = await dbUtil.getProjectById(id);
        if (!project) throw new APIError('project_not_exist');

        await prepareToDeleteProject(project);
        await project.destroy();

        ctx.rest({});

        await next();
    },

    'GET /api/member/list': async (ctx, next) => {
        const { projectId } = ctx.request.query;
        if (!projectId) throw new APIError('request_invalid');

        const project = await dbUtil.getProjectById(projectId);
        if (!project) throw new APIError('project_not_exist');

        const members = await dbUtil.getMembersWithUserByProjectId(projectId);

        ctx.rest(members);

        await next();
    },
    'POST /api/member': async (ctx, next) => {
        const targetUserId = ctx.request.fields.userId;
        const { projectId, part, role } = ctx.request.fields;
        if (!(targetUserId && projectId && part && role)) throw new APIError('request_invalid');

        const { userId } = ctx.session;
        if (!userId) throw new APIError('session_invalid');

        const user = await dbUtil.getUserById(userId);
        if (user.role !== 3) throw new APIError('permission_denied');

        const targetUser = await dbUtil.getUserById(targetUserId);
        if (!targetUser) throw new APIError('user_not_exist');

        const project = await dbUtil.getProjectById(projectId);
        if (!project) throw new APIError('project_not_exist');

        let member = {
            userId: Number(targetUserId),
            projectId: Number(projectId),
            part: Number(part),
            role: Number(role),
            score: targetUser.state === 0 ? 21 : 15,
        };
        member = await dbUtil.createMember(member);

        const schedules = await dbUtil.getSchedulesAfterTimeByProjectId(Date.now(), projectId);
        for (const schedule of schedules) {
            await dbUtil.createAttendance({
                scheduleId: schedule.id,
                memberId: member.id,
            });
            member.score -= 12;
        }
        await member.save();

        ctx.rest(member);

        await next();
    },
    'PUT /api/member': async (ctx, next) => {
        const { id, part, role } = ctx.request.fields;
        if (!id) throw new APIError('request_invalid');

        const { userId } = ctx.session;
        if (!userId) throw new APIError('session_invalid');

        const targetMember = await dbUtil.getMemberById(id);
        if (!targetMember) throw new APIError('member_not_exist');

        const user = await dbUtil.getUserById(userId);
        const member = await dbUtil.getMemberByUserIdAndProjectId(userId, targetMember.projectId);
        if (user.role !== 3 && !canManageMemberForPart(member, targetMember)) throw new APIError('permission_denied');

        if (part) {
            if (user.role !== 3 && Number(part) !== 0 && Number(part) !== member.part) throw new APIError('permission_denied');
            targetMember.part = Number(part);
        }
        if (role) targetMember.role = Number(role);
        await targetMember.save();

        ctx.rest(targetMember);

        await next();
    },
    'DELETE /api/member': async (ctx, next) => {
        const { id } = ctx.request.query;
        if (!id) throw new APIError('request_invalid');

        const { userId } = ctx.session;
        if (!userId) throw new APIError('session_invalid');

        const user = await dbUtil.getUserById(userId);
        if (user.role !== 3) throw new APIError('permission_denied');

        const member = await dbUtil.getMemberById(id);
        if (!member) throw new APIError('member_not_exist');

        await prepareToDeleteMember(member);
        await member.destroy();

        ctx.rest({});

        await next();
    },

    'GET /api/schedule/list': async (ctx, next) => {
        const { projectId } = ctx.request.query;
        if (!projectId) throw new APIError('request_invalid');

        const project = await dbUtil.getProjectById(projectId);
        if (!project) throw new APIError('project_not_exist');

        const schedules = await dbUtil.getSchedulesByProjectId(projectId);
        const shouldAttend = await dbUtil.getMemberCountByProjectId(projectId);
        for (const schedule of schedules) {
            schedule.dataValues.attendance = {
                didAttend: await dbUtil.getDidAttendAttendanceCountByScheduleId(schedule.id),
                shouldAttend,
            };
            prepareSchedule(schedule);
        }

        ctx.rest(schedules);

        await next();
    },
    'POST /api/schedule': async (ctx, next) => {
        const { projectId, name, startTime, endTime, detail } = ctx.request.fields;
        if (!(projectId && name && startTime && endTime && detail)) throw new APIError('request_invalid');

        const { userId } = ctx.session;
        if (!userId) throw new APIError('session_invalid');

        const user = await dbUtil.getUserById(userId);
        if (user.role !== 3) throw new APIError('permission_denied');

        const project = await dbUtil.getProjectById(projectId);
        if (!project) throw new APIError('project_not_exist');

        let schedule = {
            projectId: Number(projectId),
            name,
            startTime: Number(startTime),
            endTime: Number(endTime),
            detail,
        };
        schedule = await dbUtil.createSchedule(schedule);
        prepareSchedule(schedule);

        const members = await dbUtil.getMembersByProjectId(projectId);
        for (const member of members) {
            await dbUtil.createAttendance({
                scheduleId: schedule.id,
                memberId: member.id,
            });
            member.score -= 12;
            await member.save();
        }

        ctx.rest(schedule);

        await next();
    },
    'PUT /api/schedule': async (ctx, next) => {
        const { id, name, startTime, endTime, detail } = ctx.request.fields;
        if (!id) throw new APIError('request_invalid');

        const { userId } = ctx.session;
        if (!userId) throw new APIError('session_invalid');

        const user = await dbUtil.getUserById(userId);
        if (user.role !== 3) throw new APIError('permission_denied');

        const schedule = await dbUtil.getScheduleById(id);
        if (!schedule) throw new APIError('schedule_not_exist');

        if (name) schedule.name = name;
        if (startTime) schedule.startTime = Number(startTime);
        if (endTime) schedule.endTime = Number(endTime);
        if (detail) schedule.detail = detail;
        await schedule.save();
        prepareSchedule(schedule);

        ctx.rest(schedule);

        await next();
    },
    'DELETE /api/schedule': async (ctx, next) => {
        const { id } = ctx.request.query;
        if (!id) throw new APIError('request_invalid');

        const { userId } = ctx.session;
        if (!userId) throw new APIError('session_invalid');

        const user = await dbUtil.getUserById(userId);
        if (user.role !== 3) throw new APIError('permission_denied');

        const schedule = await dbUtil.getScheduleById(id);
        if (!schedule) throw new APIError('schedule_not_exist');

        const members = await dbUtil.getMembersByProjectId(schedule.projectId);
        for (const member of members) {
            member.score += 12;
            await member.save();
        }

        await schedule.destroy();

        ctx.rest({});

        await next();
    },

    'GET /api/attendance/list': async (ctx, next) => {
        const { scheduleId } = ctx.request.query;
        if (!scheduleId) throw new APIError('request_invalid');

        const schedule = await dbUtil.getScheduleById(scheduleId);
        if (!schedule) throw new APIError('schedule_not_exist');

        const attendances = await dbUtil.getAttendancesWithMemberWithUserByScheduleId(scheduleId);

        ctx.rest(attendances);

        await next();
    },
    'PUT /api/attendance': async (ctx, next) => {
        const { id, state } = ctx.request.fields;
        if (!(id && state)) throw new APIError('request_invalid');

        const { userId } = ctx.session;
        if (!userId) throw new APIError('session_invalid');

        const attendance = await dbUtil.getAttendanceById(id);
        if (!attendance) throw new APIError('attendance_not_exist');
        const targetMember = await dbUtil.getMemberById(attendance.memberId);

        const user = await dbUtil.getUserById(userId);
        if (user.role !== 3) {
            const member = await dbUtil.getMemberByUserIdAndProjectId(userId, targetMember.projectId);
            if (!isPartChiefOfMember(member, targetMember)) throw new APIError('permission_denied');
        }

        switch (attendance.state) {
            case 0: {
                switch (Number(state)) {
                    case 1: targetMember.score += 6; break;
                    case 2: targetMember.score += 10; break;
                    case 3:
                    case 4: targetMember.score += 12; break;
                }
                break;
            }
            case 1: {
                switch (Number(state)) {
                    case 0: targetMember.score -= 6; break;
                    case 2: targetMember.score += 4; break;
                    case 3:
                    case 4: targetMember.score += 6; break;
                }
                break;
            }
            case 2: {
                switch (Number(state)) {
                    case 0: targetMember.score -= 10; break;
                    case 1: targetMember.score -= 4; break;
                    case 3:
                    case 4: targetMember.score += 2; break;
                }
                break;
            }
            case 3:
            case 4: {
                switch (Number(state)) {
                    case 0: targetMember.score -= 12; break;
                    case 1: targetMember.score -= 6; break;
                    case 2: targetMember.score -= 2; break;
                }
                break;
            }
        }
        await targetMember.save();

        attendance.state = Number(state);
        await attendance.save();

        ctx.rest(attendance);

        await next();
    },

    'GET /api/file/list': async (ctx, next) => {
        const { projectId } = ctx.request.query;
        if (!projectId) throw new APIError('request_invalid');

        const project = await dbUtil.getProjectById(projectId);
        if (!project) throw new APIError('project_not_exist');

        const files = await dbUtil.getFilesWithUploaderByProjectId(projectId);
        files.forEach(prepareFile);

        ctx.rest(files);

        await next();
    },
    'POST /api/file': async (ctx, next) => {
        const { projectId, name, file } = ctx.request.fields;
        if (!(projectId && name && file)) throw new APIError('request_invalid');

        const { userId } = ctx.session;
        if (!userId) throw new APIError('session_invalid');

        const user = await dbUtil.getUserById(userId);
        if (user.role !== 3) throw new APIError('permission_denied');

        const project = await dbUtil.getProjectById(projectId);
        if (!project) throw new APIError('project_not_exist');

        let targetFile = {
            projectId: Number(projectId),
            uploaderId: userId,
            name,
            uuid: await fileUtil.saveFile(file[0], apiConfig.fileBasePath),
            updatedAt: Date.now(),
        };
        targetFile = await dbUtil.createFile(targetFile);
        prepareFile(targetFile);

        ctx.rest(targetFile);

        await next();
    },
    'PUT /api/file': async (ctx, next) => {
        const { id, name } = ctx.request.fields;
        if (!(id && name)) throw new APIError('request_invalid');

        const { userId } = ctx.session;
        if (!userId) throw new APIError('session_invalid');

        const user = await dbUtil.getUserById(userId);
        if (user.role !== 3) throw new APIError('permission_denied');

        const file = await dbUtil.getFileById(id);
        if (!file) throw new APIError('file_not_exist');

        file.name = name;
        file.updatedAt = Date.now();
        await file.save();
        prepareFile(file);

        ctx.rest(file);

        await next();
    },
    'DELETE /api/file': async (ctx, next) => {
        const { id } = ctx.request.query;
        if (!id) throw new APIError('request_invalid');

        const { userId } = ctx.session;
        if (!userId) throw new APIError('session_invalid');

        const user = await dbUtil.getUserById(userId);
        if (user.role !== 3) throw new APIError('permission_denied');

        const file = await dbUtil.getFileById(id);
        if (!file) throw new APIError('file_not_exist');

        await fileUtil.deleteFile(file.uuid, apiConfig.fileBasePath);
        await file.destroy();

        ctx.rest({});

        await next();
    },

    'GET /api/assignment/list': async (ctx, next) => {
        const { projectId } = ctx.request.query;
        if (!projectId) throw new APIError('request_invalid');

        const project = await dbUtil.getProjectById(projectId);
        if (!project) throw new APIError('project_not_exist');

        const assignments = await dbUtil.getAssignmentsWithAssignerAndExamplesByProjectId(projectId);
        assignments.forEach(assignment => assignment.examples.forEach(prepareExample));

        ctx.rest(assignments);

        await next();
    },
    'POST /api/assignment': async (ctx, next) => {
        const { projectId, part, name, detail } = ctx.request.fields;
        if (!(projectId && part && name && detail)) throw new APIError('request_invalid');

        const { userId } = ctx.session;
        if (!userId) throw new APIError('session_invalid');

        const user = await dbUtil.getUserById(userId);
        if (user.role !== 3) {
            const member = await dbUtil.getMemberByUserIdAndProjectId(userId, projectId);
            if (!isChiefOfPart(member, Number(part))) throw new APIError('permission_denied');
        }

        const project = await dbUtil.getProjectById(projectId);
        if (!project) throw new APIError('project_not_exist');

        let assignment = {
            projectId: Number(projectId),
            assignerId: userId,
            part: Number(part),
            name,
            detail,
            updatedAt: Date.now(),
        };
        assignment = await dbUtil.createAssignment(assignment);

        ctx.rest(assignment);

        await next();
    },
    'PUT /api/assignment': async (ctx, next) => {
        const { id, name, detail } = ctx.request.fields;
        if (!id) throw new APIError('request_invalid');

        const { userId } = ctx.session;
        if (!userId) throw new APIError('session_invalid');

        const assignment = await dbUtil.getAssignmentById(id);
        if (!assignment) throw new APIError('assignment_not_exist');

        const user = await dbUtil.getUserById(userId);
        if (user.role !== 3) {
            const member = await dbUtil.getMemberByUserIdAndProjectId(userId, assignment.projectId);
            if (!isChiefOfPart(member, assignment.part)) throw new APIError('permission_denied');
        }

        if (name) assignment.name = name;
        if (detail) assignment.detail = detail;
        assignment.updatedAt = Date.now();
        await assignment.save();

        ctx.rest(assignment);

        await next();
    },
    'DELETE /api/assignment': async (ctx, next) => {
        const { id } = ctx.request.query;
        if (!id) throw new APIError('request_invalid');

        const { userId } = ctx.session;
        if (!userId) throw new APIError('session_invalid');

        const assignment = await dbUtil.getAssignmentById(id);
        if (!assignment) throw new APIError('assignment_not_exist');

        const user = await dbUtil.getUserById(userId);
        if (user.role !== 3) {
            const member = await dbUtil.getMemberByUserIdAndProjectId(userId, assignment.projectId);
            if (!isChiefOfPart(member, assignment.part)) throw new APIError('permission_denied');
        }

        await prepareToDeleteAssignment(assignment);
        await assignment.destroy();

        ctx.rest({});

        await next();
    },

    'POST /api/example': async (ctx, next) => {
        const { assignmentId, name, file } = ctx.request.fields;
        if (!(assignmentId && name && file)) throw new APIError('request_invalid');

        const { userId } = ctx.session;
        if (!userId) throw new APIError('session_invalid');

        const assignment = await dbUtil.getAssignmentById(assignmentId);
        if (!assignment) throw new APIError('assignment_not_exist');

        const user = await dbUtil.getUserById(userId);
        if (user.role !== 3) {
            const member = await dbUtil.getMemberByUserIdAndProjectId(userId, assignment.projectId);
            if (!isChiefOfPart(member, assignment.part)) throw new APIError('permission_denied');
        }

        let example = {
            assignmentId: Number(assignmentId),
            name,
            uuid: await fileUtil.saveFile(file[0], apiConfig.exampleBasePath),
            updatedAt: Date.now(),
        };
        example = await dbUtil.createExample(example);
        prepareExample(example);

        ctx.rest(example);

        await next();
    },
    'PUT /api/example': async (ctx, next) => {
        const { id, name } = ctx.request.fields;
        if (!(id && name)) throw new APIError('request_invalid');

        const { userId } = ctx.session;
        if (!userId) throw new APIError('session_invalid');

        const example = await dbUtil.getExampleById(id);
        if (!example) throw new APIError('example_not_exist');
        const assignment = await dbUtil.getAssignmentById(example.assignmentId);

        const user = await dbUtil.getUserById(userId);
        if (user.role !== 3) {
            const member = await dbUtil.getMemberByUserIdAndProjectId(userId, assignment.projectId);
            if (!isChiefOfPart(member, assignment.part)) throw new APIError('permission_denied');
        }

        example.name = name;
        example.updatedAt = Date.now();
        await example.save();
        prepareExample(example);

        ctx.rest(example);

        await next();
    },
    'DELETE /api/example': async (ctx, next) => {
        const { id } = ctx.request.query;
        if (!id) throw new APIError('request_invalid');

        const { userId } = ctx.session;
        if (!userId) throw new APIError('session_invalid');

        const example = await dbUtil.getExampleById(id);
        if (!example) throw new APIError('example_not_exist');
        const assignment = await dbUtil.getAssignmentById(example.assignmentId);

        const user = await dbUtil.getUserById(userId);
        if (user.role !== 3) {
            const member = await dbUtil.getMemberByUserIdAndProjectId(userId, assignment.projectId);
            if (!isChiefOfPart(member, assignment.part)) throw new APIError('permission_denied');
        }

        await fileUtil.deleteFile(example.uuid, apiConfig.exampleBasePath);
        await example.destroy();

        ctx.rest({});

        await next();
    },

    'GET /api/work/list': async (ctx, next) => {
        const { assignmentId } = ctx.request.query;
        if (!assignmentId) throw new APIError('request_invalid');

        const assignment = await dbUtil.getAssignmentById(assignmentId);
        if (!assignment) throw new APIError('assignment_not_exist');

        const works = await dbUtil.getWorksWithMemberWithUserByAssignmentId(assignmentId);

        let evaluatedCount = 0;
        let best = { score: 0 };
        for (const work of works) {
            prepareWork(work);
            const evaluations = await dbUtil.getEvaluationsByWorkId(work.id);
            if (evaluations.length > 0) {
                evaluatedCount++;
                const score = calcWorkScore(evaluations);
                if (score > best.score) best = { id: work.id, score };
            }
        }

        ctx.rest({
            list: works,
            best: evaluatedCount > (works.length / 2) ? best : null,
        });

        await next();
    },
    'POST /api/work': async (ctx, next) => {
        const { assignmentId, memberId, subpart, file } = ctx.request.fields;
        if (!(assignmentId && memberId && subpart && file)) throw new APIError('request_invalid');

        const { userId } = ctx.session;
        if (!userId) throw new APIError('session_invalid');

        const targetMember = await dbUtil.getMemberById(memberId);
        if (!targetMember) throw new APIError('member_not_exist');

        const user = await dbUtil.getUserById(userId);
        if (targetMember.userId !== userId && user.role !== 3) {
            const member = await dbUtil.getMemberByUserIdAndProjectId(userId, targetMember.projectId);
            if (!isPartChiefOfMember(member, targetMember)) throw new APIError('permission_denied');
        }

        const assignment = await dbUtil.getAssignmentById(assignmentId);
        if (!assignment) throw new APIError('assignment_not_exist');

        let work = await dbUtil.getWorkByAssignmentIdAndMemberId(assignmentId, memberId);
        if (work) throw new APIError('work_existed');

        work = {
            assignmentId: Number(assignmentId),
            memberId: Number(memberId),
            subpart: Number(subpart),
            uuid: await fileUtil.saveFile(file[0], apiConfig.workBasePath),
            updatedAt: Date.now(),
        };
        work = await dbUtil.createWork(work);
        prepareWork(work);

        ctx.rest(work);

        await next();
    },
    'PUT /api/work': async (ctx, next) => {
        const { id, subpart, file } = ctx.request.fields;
        if (!id) throw new APIError('request_invalid');

        const { userId } = ctx.session;
        if (!userId) throw new APIError('session_invalid');

        const work = await dbUtil.getWorkById(id);
        if (!work) throw new APIError('work_not_exist');

        const targetMember = await dbUtil.getMemberById(work.memberId);
        const user = await dbUtil.getUserById(userId);
        if (targetMember.userId !== userId && user.role !== 3) {
            const member = await dbUtil.getMemberByUserIdAndProjectId(userId, targetMember.projectId);
            if (!isPartChiefOfMember(member, targetMember)) throw new APIError('permission_denied');
        }

        if (subpart) work.subpart = Number(subpart);
        if (file) {
            await fileUtil.deleteFile(work.uuid, apiConfig.workBasePath);
            work.uuid = await fileUtil.saveFile(file[0], apiConfig.workBasePath);
        }
        work.updatedAt = Date.now();
        await work.save();
        prepareWork(work);

        ctx.rest(work);

        await next();
    },
    'DELETE /api/work': async (ctx, next) => {
        const { id } = ctx.request.query;
        if (!id) throw new APIError('request_invalid');

        const { userId } = ctx.session;
        if (!userId) throw new APIError('session_invalid');

        const work = await dbUtil.getWorkById(id);
        if (!work) throw new APIError('work_not_exist');

        const targetMember = await dbUtil.getMemberById(work.memberId);
        const user = await dbUtil.getUserById(userId);
        if (targetMember.userId !== userId && user.role !== 3) {
            const member = await dbUtil.getMemberByUserIdAndProjectId(userId, targetMember.projectId);
            if (!isPartChiefOfMember(member, targetMember)) throw new APIError('permission_denied');
        }
        
        await fileUtil.deleteFile(work.uuid, apiConfig.workBasePath);
        await work.destroy();

        ctx.rest({});

        await next();
    },

    'GET /api/evaluation/list': async (ctx, next) => {
        const { workId } = ctx.request.query;
        if (!workId) throw new APIError('request_invalid');

        const { userId } = ctx.session;
        if (!userId) throw new APIError('session_invalid');

        const work = await dbUtil.getWorkById(workId);
        if (!work) throw new APIError('work_not_exist');

        const member = await dbUtil.getMemberById(work.memberId);
        if (member.userId !== userId) throw new APIError('permission_denied');

        const evaluations = await dbUtil.getEvaluationsWithEvaluatorByWorkId(workId);

        ctx.rest(evaluations);

        await next();
    },
    'POST /api/evaluation': async (ctx, next) => {
        const { workId, readingScore, accuracyScore, qualityScore, plasticityScore, comment } = ctx.request.fields;
        if (!(workId && readingScore && accuracyScore && qualityScore && plasticityScore && comment)) throw new APIError('request_invalid');

        const { userId } = ctx.session;
        if (!userId) throw new APIError('session_invalid');

        const work = await dbUtil.getWorkById(workId);
        if (!work) throw new APIError('work_not_exist');

        const user = await dbUtil.getUserById(userId);
        if (user.role !== 3) {
            const targetMember = await dbUtil.getMemberById(work.memberId);
            const member = await dbUtil.getMemberByUserIdAndProjectId(userId, targetMember.projectId);
            if (!isPartChiefOfMember(member, targetMember)) throw new APIError('permission_denied');
        }

        let evaluation = {
            workId: Number(workId),
            evaluatorId: userId,
            readingScore: Number(readingScore),
            accuracyScore: Number(accuracyScore),
            qualityScore: Number(qualityScore),
            plasticityScore: Number(plasticityScore),
            comment,
            updatedAt: Date.now(),
        };
        evaluation = await dbUtil.createEvaluation(evaluation);

        const evaluations = await dbUtil.getEvaluationsByWorkId(workId);
        evaluation.dataValues.score = calcWorkScore(evaluations);

        ctx.rest(evaluation);

        await next();
    },
    'PUT /api/evaluation': async (ctx, next) => {
        const { id, readingScore, accuracyScore, qualityScore, plasticityScore, comment } = ctx.request.fields;
        if (!id) throw new APIError('request_invalid');

        const { userId } = ctx.session;
        if (!userId) throw new APIError('session_invalid');

        const evaluation = await dbUtil.getEvaluationById(id);
        if (!evaluation) throw new APIError('evaluation_not_exist');

        if (evaluation.evaluatorId !== userId) throw new APIError('permission_denied');

        if (readingScore) evaluation.readingScore = Number(readingScore);
        if (accuracyScore) evaluation.accuracyScore = Number(accuracyScore);
        if (qualityScore) evaluation.qualityScore = Number(qualityScore);
        if (plasticityScore) evaluation.plasticityScore = Number(plasticityScore);
        if (comment) evaluation.comment = comment;
        evaluation.updatedAt = Date.now();
        await evaluation.save();

        const evaluations = await dbUtil.getEvaluationsByWorkId(evaluation.workId);
        evaluation.dataValues.score = calcWorkScore(evaluations);

        ctx.rest(evaluation);

        await next();
    },
    'DELETE /api/evaluation': async (ctx, next) => {
        const { id } = ctx.request.query;
        if (!id) throw new APIError('request_invalid');

        const { userId } = ctx.session;
        if (!userId) throw new APIError('session_invalid');

        const evaluation = await dbUtil.getEvaluationById(id);
        if (!evaluation) throw new APIError('evaluation_not_exist');

        if (evaluation.evaluatorId !== userId) throw new APIError('permission_denied');

        await evaluation.destroy();

        ctx.rest({});

        await next();
    },
};

function isPartChiefOfUser(members, targetMembers) {
    for (const member of members) {
        if (member.role === 1) {
            for (const targetMember of targetMembers) {
                if (targetMember.projectId === member.projectId && targetMember.part === member.part)
                    return true;
            }
        }
    }
    return false;
}

function isPartChiefOfMember(member, targetMember) {
    return isChiefOfPart(member, targetMember.part);
}

function isChiefOfPart(member, part) {
    if (!member) return false;
    return member.role === 1 && member.part === part;
}

function canManageMemberForPart(member, targetMember) {
    if (!member) return false;
    return member.role === 1 && (targetMember.part === 0 || targetMember.part === member.part);
}

function prepareProject(project) {
    project.detail = JSON.parse(project.detail);
    if (project.imageUuid) project.dataValues.imageUrl = fileUtil.fileUuidToUrl(project.imageUuid, apiConfig.imageBaseUrl);
    delete project.dataValues.imageUuid;
}

function prepareSchedule(schedule) {
    schedule.detail = JSON.parse(schedule.detail);
}

function prepareFile(file) {
    file.dataValues.url = fileUtil.fileUuidToUrl(file.uuid, apiConfig.fileBaseUrl);
    delete file.dataValues.uuid;
}

function prepareExample(example) {
    example.dataValues.url = fileUtil.fileUuidToUrl(example.uuid, apiConfig.exampleBaseUrl);
    delete example.dataValues.uuid;
}

function prepareWork(work) {
    work.dataValues.url = fileUtil.fileUuidToUrl(work.uuid, apiConfig.workBaseUrl);
    delete work.dataValues.uuid;
}

function calcWorkScore(evaluations) {
    let total = 0;
    evaluations.forEach(evaluation => total += ((evaluation.readingScore + evaluation.accuracyScore + evaluation.qualityScore + evaluation.plasticityScore) / 4));
    return total / evaluations.length;
}

async function prepareToDeleteUser(user) {
    const members = await dbUtil.getMembersByUserId(user.id);
    for (const member of members) await prepareToDeleteMember(member);
    const files = await dbUtil.getFilesByUploaderId(user.id);
    for (const file of files) await fileUtil.deleteFile(file.uuid, apiConfig.fileBasePath);
    const assignments = await dbUtil.getAssignmentsByAssignerId(user.id);
    for (const assignment of assignments) await prepareToDeleteAssignment(assignment);
}

async function prepareToDeleteProject(project) {
    if (project.imageUuid) await fileUtil.deleteFile(project.imageUuid, apiConfig.imageBasePath);
    const files = await dbUtil.getFilesByProjectId(project.id);
    for (const file of files) await fileUtil.deleteFile(file.uuid, apiConfig.fileBasePath);
    const assignments = await dbUtil.getAssignmentsByProjectId(project.id);
    for (const assignment of assignments) await prepareToDeleteAssignment(assignment);
}

async function prepareToDeleteMember(member) {
    const works = await dbUtil.getWorksByMemberId(member.id);
    for (const work of works) await fileUtil.deleteFile(work.uuid, apiConfig.workBasePath);
}

async function prepareToDeleteAssignment(assignment) {
    const examples = await dbUtil.getExamplesByAssignmentId(assignment.id);
    for (const example of examples) await fileUtil.deleteFile(example.uuid, apiConfig.exampleBasePath);
    const works = await dbUtil.getWorksByAssignmentId(assignment.id);
    for (const work of works) await fileUtil.deleteFile(work.uuid, apiConfig.workBasePath);
}
