const fs = require('fs').promises;
const uuidv4 = require('uuid/v4');

module.exports = {
    saveFile: async (file, basePath) => {
        const uuid = uuidv4();
        await fs.copyFile(file.path, `${basePath}/${uuid}`);
        return uuid;
    },
    deleteFile: async (uuid, basePath) => await fs.unlink(`${basePath}/${uuid}`),
    fileUuidToUrl: (uuid, baseUrl) => `${baseUrl}/${uuid}`,
};
