const Op = require('sequelize').Op;

const model = require('../model');
const User = model.users;
const Project = model.projects;
const Member = model.members;
const Schedule = model.schedules;
const Attendance = model.attendances;
const File = model.files;
const Assignment = model.assignments;
const Example = model.examples;
const Work = model.works;
const Evaluation = model.evaluations;

module.exports = {
    createUser: async user => await User.create(user),
    getUserById: async id => await User.findByPk(id),
    getUserByOpenId: async openId => await User.findOne({ where: { openId } }),
    getUsers: async () => await User.findAll(),

    createProject: async project => await Project.create(project),
    getProjectById: async id => await Project.findByPk(id),
    getProjects: async () => await Project.findAll(),

    createMember: async member => await Member.create(member),
    getMemberById: async id => await Member.findByPk(id),
    getMemberByUserIdAndProjectId: async (userId, projectId) => await Member.findOne({ where: { userId, projectId } }),
    getMembersByUserId: async userId => await Member.findAll({ where: { userId } }),
    getMembersWithProjectByUserId: async userId => await Member.findAll({ where: { userId }, include: [Project] }),
    getMemberCountByProjectId: async projectId => await Member.count({ where: { projectId } }),
    getMembersByProjectId: async projectId => await Member.findAll({ where: { projectId } }),
    getMembersWithUserByProjectId: async projectId => await Member.findAll({ where: { projectId }, include: [User] }),

    createSchedule: async schedule => await Schedule.create(schedule),
    getScheduleById: async id => await Schedule.findByPk(id),
    getSchedulesByProjectId: async projectId => await Schedule.findAll({ where: { projectId } }),
    getSchedulesAfterTimeByProjectId: async (time, projectId) => await Schedule.findAll({ where: { projectId, startTime: { [Op.gt]: time } } }),

    createAttendance: async attendance => await Attendance.create(attendance),
    getAttendanceById: async id => await Attendance.findByPk(id),
    getDidAttendAttendanceCountByScheduleId: async scheduleId => await Attendance.count({ where: { scheduleId, state: { [Op.in]: [2, 4] } } }),
    getAttendancesWithMemberWithUserByScheduleId: async scheduleId => await Attendance.findAll({ where: { scheduleId }, include: [{ model: Member, include: [User] }] }),

    createFile: async file => await File.create(file),
    getFileById: async id => await File.findByPk(id),
    getFilesByProjectId: async projectId => await File.findAll({ where: { projectId } }),
    getFilesByUploaderId: async uploaderId => await File.findAll({ where: { uploaderId } }),
    getFilesWithUploaderByProjectId: async projectId => await File.findAll({ where: { projectId }, include: [{ model: User, as: 'uploader' }] }),

    createAssignment: async assignment => await Assignment.create(assignment),
    getAssignmentById: async id => await Assignment.findByPk(id),
    getAssignmentsByProjectId: async projectId => await Assignment.findAll({ where: { projectId } }),
    getAssignmentsByAssignerId: async assignerId => await Assignment.findAll({ where: { assignerId } }),
    getAssignmentsWithAssignerAndExamplesByProjectId: async projectId => await Assignment.findAll({ where: { projectId }, include: [{ model: User, as: 'assigner' }, Example] }),

    createExample: async example => await Example.create(example),
    getExampleById: async id => await Example.findByPk(id),
    getExamplesByAssignmentId: async assignmentId => await Example.findAll({ where: { assignmentId } }),

    createWork: async work => await Work.create(work),
    getWorkById: async id => await Work.findByPk(id),
    getWorksByAssignmentId: async assignmentId => await Work.findAll({ where: { assignmentId } }),
    getWorksByMemberId: async memberId => await Work.findAll({ where: { memberId } }),
    getWorkByAssignmentIdAndMemberId: async (assignmentId, memberId) => await Work.findOne({ where: { assignmentId, memberId } }),
    getWorksWithMemberWithUserByAssignmentId: async assignmentId => await Work.findAll({ where: { assignmentId }, include: [{ model: Member, include: [User] }] }),

    createEvaluation: async evaluation => await Evaluation.create(evaluation),
    getEvaluationById: async id => await Evaluation.findByPk(id),
    getEvaluationsByWorkId: async workId => await Evaluation.findAll({ where: { workId } }),
    getEvaluationsWithEvaluatorByWorkId: async workId => await Evaluation.findAll({ where: { workId }, include: [{ model: User, as: 'evaluator' }] }),
};
